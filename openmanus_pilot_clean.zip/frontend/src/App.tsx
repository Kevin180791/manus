
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import RoomData from './pages/RoomData';
import FlowCalc from './pages/FlowCalc';

function App() {
  return (
    <Router>
      <div className="flex">
        <nav className="w-64 bg-gray-800 text-white p-4 min-h-screen">
          <h1 className="text-xl font-bold mb-4">OpenManus</h1>
          <ul>
            <li><Link to="/">Dashboard</Link></li>
            <li><Link to="/raumdaten">Raumdaten</Link></li>
          </ul>
        </nav>
        <main className="flex-1 p-4">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/raumdaten" element={<RoomData />} />
            <Route path="/stroemung" element={<FlowCalc />} />
</Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
