
function Dashboard() {
  return <h2>Dashboard Startseite</h2>;
}
export default Dashboard;
