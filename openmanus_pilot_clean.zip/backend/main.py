
from fastapi import FastAPI
from routers import agent_tasks, upload_router, flowcalc_tasks

app = FastAPI(title="OpenManus KI-Plattform", version="1.0")

# Routen registrieren
app.include_router(agent_tasks.router, prefix="/agent/tasks")
app.include_router(upload_router.router, prefix="/documents")
app.include_router(flowcalc_tasks.router, prefix="/agent/tasks")

@app.get("/")
def root():
    return {"message": "OpenManus KI-Plattform Backend läuft"}
